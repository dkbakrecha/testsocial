<?php

App::uses('AppModel', 'Model');

class ToolSetting extends AppModel {
    
}