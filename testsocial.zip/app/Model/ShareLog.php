<?php
App::uses('AppModel', 'Model');

class SharedLog extends AppModel {
}