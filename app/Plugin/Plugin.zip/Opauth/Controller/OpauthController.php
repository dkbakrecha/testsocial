<?php
class OpauthController extends OpauthAppController {
}