List of Events
==============

List of events that are triggered in this plugin

 * Cart.applyDiscounts
 * Cart.applyTaxRules
 * Cart.afterCalculateCart
 * CartManager.beforeAddItem
 * CartManager.afterAddItem
 * CartManager.beforeRemoveItem
 * CartManager.afterRemoveItem
 * Order.beforeCreateOrder
 * Order.created