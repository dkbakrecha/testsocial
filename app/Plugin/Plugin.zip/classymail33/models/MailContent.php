<?php
/**
 * Description of MailContent
 *
 * @author dharmendra
 */
class MailContent extends ClassymailAppModel{
    //put your code here
    
}
