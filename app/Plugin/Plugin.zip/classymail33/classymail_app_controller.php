<?php

class ClassymailAppController extends AppController {

}

?>