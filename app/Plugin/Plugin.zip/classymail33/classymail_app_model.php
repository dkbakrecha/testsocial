<?php

class ClassymailAppModel extends AppModel {

}

?>